import sqlite3

#Postgresql password: JyM9560!
#Username Postgres
#Post password: 5432

def connect():
    conn=sqlite3.connect("books.db")
    cur=conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS BOOK (id INTEGER PRIMARY KEY, first text, last text, year integer, major text)")
    conn.commit()
    conn.close()

def insert(first, last, year, major):
    conn=sqlite3.connect("books.db")
    cur=conn.cursor()
    cur.execute("INSERT INTO book VALUES  (NULL,?,?,?,?)", (first,last,year,major))
    conn.commit()
    conn.close()

def view():
    conn=sqlite3.connect("books.db")
    cur=conn.cursor()
    cur.execute("SELECT * FROM book")
    rows=cur.fetchall()
    conn.close()
    return rows

def search(first="",last="",year="",major=""):
    conn=sqlite3.connect("books.db")
    cur=conn.cursor()
    cur.execute("SELECT * FROM book WHERE first=? OR last=? OR year=? OR major=?", (first,last,year,major))
    rows=cur.fetchall()
    conn.close()
    return rows

def delete(id):
    conn=sqlite3.connect("books.db")
    cur=conn.cursor()
    cur.execute("DELETE FROM book WHERE id=?", (id,))
    conn.commit()
    conn.close()

def update(id,first,last,year,major):
    conn=sqlite3.connect("books.db")
    cur=conn.cursor()
    cur.execute("UPDATE book SET first=?, last=?, year=?, major=? WHERE id=?", (first,last,year,major,id))
    conn.commit()
    conn.close()

connect()
#insert("The Sun", "John Smock", 1918, 192823)
#delete(3)
#update(4, "The moon", "John smooth", 1917, 1920003)
#print(view())
#print(search(author="John Smock"))